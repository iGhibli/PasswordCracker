//
//  PasswordCrackerApp.swift
//  PasswordCracker
//
//  Created by iGhibli on 2021/1/19.
//

import SwiftUI

@main
struct PasswordCrackerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView(inputText: .constant(""))
        }
    }
}
