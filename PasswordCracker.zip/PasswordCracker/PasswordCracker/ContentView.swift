//
//  ContentView.swift
//  PasswordCracker
//
//  Created by iGhibli on 2021/1/19.
//

import SwiftUI

struct ContentView: View {
    
    @Binding var inputText: String
    
    var body: some View {
        VStack {
            TextField("录入已尝试密码", text: $inputText)
                .keyboardType(.numberPad)
                .font(.system(size: 36, weight: .bold, design: .rounded))
                .multilineTextAlignment(.center)
                .overlay(RoundedRectangle(cornerRadius: 8.0, style: .continuous).stroke(Color.green, lineWidth: 1.0))
            Button(action: {}) {
                Text("录入")
                    .font(.system(size: 32, weight: .bold, design: .rounded))
                }
            .overlay(RoundedRectangle(cornerRadius: 8.0, style: .continuous).stroke(Color.blue, lineWidth: 2.0))
        }.padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(inputText: .constant(""))
    }
}
